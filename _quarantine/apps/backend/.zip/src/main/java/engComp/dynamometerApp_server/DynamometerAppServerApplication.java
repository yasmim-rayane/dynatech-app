package engComp.dynamometerApp_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class DynamometerAppServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamometerAppServerApplication.class, args);
	}

}
